name = 'scadparser'
__version__ = "v0.1.1"
