from .cli import cli

# python -m scadparser
if __name__ == '__main__':
    cli()
